fx_version 'cerulean'
game 'gta5'

author 'LKC'
description 'Standalone Peacetime Script (blocks weapons and fighting when enabled)'

client_script 'client.lua'
server_script 'server.lua'
shared_script 'config.lua'
