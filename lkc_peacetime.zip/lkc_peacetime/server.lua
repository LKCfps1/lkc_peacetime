local peacetime = false
local autoPeacetime = false
local resourceStartTime = os.time()


dofile('config.lua')


RegisterCommand('peacetime', function(source)
    if IsPlayerAceAllowed(source, "command") or source == 0 then
        peacetime = not peacetime
        autoPeacetime = false 
        TriggerClientEvent('lkc_peacetime:set', -1, peacetime)
        if peacetime then
            print('[PEACETIME] Peacetime ENABLED by', GetPlayerName(source))
        else
            print('[PEACETIME] Peacetime DISABLED by', GetPlayerName(source))
        end
    else
        TriggerClientEvent('chat:addMessage', source, { args = { '^1SYSTEM', 'No permission.' } })
    end
end)


if Config.UseAutoPeacetime then
    CreateThread(function()
        while true do
            Wait(10000) 
            local uptime = (os.time() - resourceStartTime) / 60 
            local restartTime = Config.ServerRestartMinutes
            if uptime <= Config.PeacetimeStartMinutes or uptime >= (restartTime - Config.PeacetimeEndMinutes) then
                if not peacetime or not autoPeacetime then
                    peacetime = true
                    autoPeacetime = true
                    TriggerClientEvent('lkc_peacetime:set', -1, true)
                    print("[PEACETIME] Auto-peacetime ENABLED (restart window)")
                end
            else
                if autoPeacetime then
                    peacetime = false
                    autoPeacetime = false
                    TriggerClientEvent('lkc_peacetime:set', -1, false)
                    print("[PEACETIME] Auto-peacetime DISABLED (outside restart window)")
                end
            end
        end
    end)
end

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    Wait(1000)
    TriggerClientEvent('lkc_peacetime:set', source, peacetime)
end)
