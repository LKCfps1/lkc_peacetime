Config = {}

Config.UseAutoPeacetime = true  -- Set to false to disable automatic peacetime at restart
Config.PeacetimeStartMinutes = 30  -- Peacetime ON for this many minutes after server (resource) starts
Config.PeacetimeEndMinutes = 30    -- Peacetime ON for this many minutes before next restart (set high if no auto restart)
Config.ServerRestartMinutes = 240  -- Total time (in minutes) between scheduled restarts (e.g. 4 hours = 240)
