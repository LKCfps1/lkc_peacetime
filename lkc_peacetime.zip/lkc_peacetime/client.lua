local peacetime = false

RegisterNetEvent('lkc_peacetime:set', function(state)
    peacetime = state
    if peacetime then
        Notify("Peacetime is now **ACTIVE**. All combat and weapons are disabled!")
    else
        Notify("Peacetime is now OFF. Play safe!")
    end
end)

function Notify(msg)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(msg)
    DrawNotification(false, false)
end


CreateThread(function()
    while true do
        Wait(0)
        if peacetime then
            SetCurrentPedWeapon(PlayerPedId(), `WEAPON_UNARMED`, true)
            DisableControlAction(0, 24, true)   -- Attack
            DisableControlAction(0, 25, true)   -- Aim
            DisableControlAction(0, 69, true)   -- Vehicle attack
            DisableControlAction(0, 92, true)   -- Vehicle aim
            DisableControlAction(0, 140, true)  -- Melee attack light
            DisableControlAction(0, 141, true)  -- Melee attack heavy
            DisableControlAction(0, 142, true)  -- Melee attack alternate
            DisableControlAction(0, 257, true)  -- Attack 2
            DisableControlAction(0, 263, true)  -- Melee attack 1
            DisableControlAction(0, 264, true)  -- Melee attack 2
            DisablePlayerFiring(PlayerPedId(), true)
            DisableControlAction(0, 170, true)  -- F3 (block)
            DisableControlAction(0, 303, false) -- U (allow)
            DisableControlAction(0, 29, false)  -- B (allow)
            DisableControlAction(0, 20, false)  -- Z (allow)
            DisableControlAction(0, 73, false)  -- X (allow)
            DisableControlAction(0, 244, false) -- M (allow)
        end
    end
end)


local showPeacetimeUI = false

RegisterNetEvent('lkc_peacetime:set', function(state)
    peacetime = state
    showPeacetimeUI = state
    if peacetime then
        Notify("Peacetime is now **ACTIVE**. All combat and weapons are disabled!")
    else
        Notify("Peacetime is now OFF. Play safe!")
    end
end)

CreateThread(function()
    while true do
        Wait(0)
        if showPeacetimeUI then
            local x, y, width, height = 0.88, 0.09, 0.20, 0.05 
            DrawRect(x, y, width, height, 40, 200, 40, 200)
            DrawRect(x, y, width+0.004, height+0.008, 255, 255, 255, 40)
            SetTextFont(4) 
            SetTextScale(0.55, 0.55)
            SetTextColour(255, 255, 255, 255)
            SetTextCentre(true)
            SetTextOutline()
            BeginTextCommandDisplayText("STRING")
            AddTextComponentSubstringPlayerName("PEACETIME ENABLED")
            EndTextCommandDisplayText(x, y-0.015)
        end
    end
end)

